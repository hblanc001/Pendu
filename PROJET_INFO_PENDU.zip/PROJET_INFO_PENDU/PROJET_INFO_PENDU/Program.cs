﻿using System;

namespace PROJET_INFO_PENDU
{
    class Program
    {

        static void Main(string[] args)
        {
            string[,] pendu = new string[11, 20];

            Initialisation_Partie();
            Initialiser_Pendu(pendu);
            Affiche_Pendu(pendu, 3);           
           
        }



        public static void Initialiser_Pendu(string[,] pendu)
        {
            for (int i = 0; i < pendu.GetLength(0); i++) // initialisation d'une matrice(11x20) pleine d'espace vide
            {
                for (int j = 0; j < pendu.GetLength(1); j++)
                {
                    pendu[i, j] = " ";
                }
            }

            for (int i=1;i<pendu.GetLength(0);i++) // on créé les frontières verticales du cadre de gauche et de droite
            {
                pendu[i, 0] = "|";
                pendu[i, 19] = "|";
            }
            for (int j=1; j<pendu.GetLength(1); j++)  // on créé les frontières horizontales du cadre du haut et du bas
            {
                pendu[0, j] = "-";
                pendu[10, j] = "-";
            }
            pendu[0, 0] = "+";  //coin supérieur gauche
            pendu[0, 19] = "+"; //etc
            pendu[10, 0] = "+";
            pendu[10, 19] = "+";
            
        }



        public static void Potence(string[,] pendu)
        {
            for (int j=3;j<15; j++) // dessin du sol de la potence
            {
                pendu[8, j] = "_";
            }

            for (int i=2;i<9;i++)  // dessin de la barre verticale de la potence
            {
                pendu[i, 4] = "|";
            }
            for (int j = 5; j < 16; j++)  // dessin du reste de la potence (barre horizontale + corde + poutre de soutien)
            {
                pendu[2, j] = "-";
            }
            pendu[2, 13] = "|";
            pendu[2, 6] = "/";
            pendu[3, 5] = "/";

        }




        public static void Tete(string[,] pendu)
        {
            pendu[3, 13] = "O";
        }



        public static void Corps(string[,] pendu)
        {
            pendu[4, 13] = "|";
            pendu[5, 13] = "|";
        }



        public static void Bras_Gauche(string[,] pendu)
        {
            pendu[4, 12] = "/";
        }



        public static void Bras_Droit(string[,] pendu)
        {
            pendu[4, 14] ="/";
        }



        public static void Jambe_Gauche(string[,] pendu)
        {
            pendu[6, 12] = "/";
        }



        public static void Jambe_Droite(string[,] pendu)
        {
            pendu[6, 14] = "/";
        }



        public static void Initialisation_Partie()
        {
            Console.WriteLine("********************");
            Console.WriteLine("*** JEU DU PENDU ***");
            Console.WriteLine("********************");
            Console.WriteLine();

            Console.WriteLine("Nom du Joueur 1 ?");
            string Joueur1 = Console.ReadLine();
            Console.WriteLine("Nom du Joueur 2 ?");
            string Joueur2 = Console.ReadLine();
            Console.WriteLine();
           
            int test1 = 1;
            string role1 = " ";
            string role2 = " ";
            while (test1!=0)  // on s'assure avec cette boucle que le joueur choisisse bien une des reponses proposées (1 ou 2)
            {
                Console.WriteLine("Quel rôle souhaites-tu jouer {0} ? Tapes 1 pour 'faire deviner le mot' ou 2 pour 'chercher le mot' ", Joueur1);
                int reponse = int.Parse(Console.ReadLine());
                if (reponse==1)
                {
                    role1 = "Choisisseur_Du_Mot";
                    role2 = "Chercheur_D'un_Mot";
                    test1 = 0;
                }
                else if (reponse==2)
                {
                    role1 = "Chercheur_Du_Mot";
                    role2 = "Choisisseur_D'un_Mot";
                    test1 = 0;
                }
            }
            Console.WriteLine("La Partie va commencer ! {0} a le rôle du {1} , {2} a le rôle du {3}.", Joueur1, role1, Joueur2, role2);
            Console.WriteLine();
            


        }



        public static void Affiche_Pendu(string[,] pendu, int Nb_Erreur)
        {
            switch(Nb_Erreur)  // A chaque nouvelle erreur, une partie du pendu devient visible
            {
                case 1:
                    Potence(pendu);
                    break;
                case 2:
                    Potence(pendu);
                    Tete(pendu);
                    break;
                case 3:
                    Potence(pendu);
                    Tete(pendu);
                    Corps(pendu);
                    break;
                case 4:
                    Potence(pendu);
                    Tete(pendu);
                    Corps(pendu);
                    Bras_Gauche(pendu);
                    break;
                case 5:
                    Potence(pendu);
                    Tete(pendu);
                    Corps(pendu);
                    Bras_Gauche(pendu);
                    Bras_Droit(pendu);
                    break;
                case 6:
                    Potence(pendu);
                    Tete(pendu);
                    Corps(pendu);
                    Bras_Gauche(pendu);
                    Bras_Droit(pendu);
                    Jambe_Gauche(pendu);
                    break;
                case 7:
                    Potence(pendu);
                    Tete(pendu);
                    Corps(pendu);
                    Bras_Gauche(pendu);
                    Bras_Droit(pendu);
                    Jambe_Gauche(pendu);
                    Jambe_Droite(pendu);
                    break;
            }

            for (int i = 0; i < pendu.GetLength(0); i++)    // affichage du pendu
            {
                for (int j = 0; j < pendu.GetLength(1); j++)
                {
                    Console.Write(pendu[i, j]);
                }
                Console.WriteLine();
            }

        }




    }
}

// DESSIN DU PENDU :
/* +------------------+
   |                  |
   |   |-/------|--   |
   |   |/       0     | 
   |   |       /|/    |
   |   |        |     |
   |   |       / /    |
   |   |              |
   |  _|__________    |
   |                  |
   +------------------+ */