﻿using System;


namespace PROJET_INFO_PENDU
{

    class Program
    {
        static void Main(string[] args)
        {

            string[,] pendu = new string[11, 20];
            Initialiser_Pendu(pendu);
            Initialisation_Partie(pendu);

        }


        public static string[] InitialiserTabMots(string NomDico) // renvoi un tableau qui contient tous les mots du dico
        {
            string[] tabMots = System.IO.File.ReadAllLines(NomDico);//lit chaque ligne du fichier dico_fr.txt et le stocke dans un tableau            
            return tabMots;
        }

        public static void Initialiser_Pendu(string[,] pendu)
        {
            for (int i = 0; i < pendu.GetLength(0); i++) // initialisation d'une matrice(11x20) pleine d'espace vide
            {
                for (int j = 0; j < pendu.GetLength(1); j++)
                {
                    pendu[i, j] = " ";
                }
            }

            for (int i = 1; i < pendu.GetLength(0); i++) // on créé les frontières verticales du cadre de gauche et de droite
            {
                pendu[i, 0] = "|";
                pendu[i, 19] = "|";
            }
            for (int j = 1; j < pendu.GetLength(1); j++)  // on créé les frontières horizontales du cadre du haut et du bas
            {
                pendu[0, j] = "-";
                pendu[10, j] = "-";
            }
            pendu[0, 0] = "+";  //coin supérieur gauche
            pendu[0, 19] = "+"; //etc
            pendu[10, 0] = "+";
            pendu[10, 19] = "+";

        }



        public static void Potence(string[,] pendu)
        {
            for (int j = 3; j < 15; j++) // dessin du sol de la potence
            {
                pendu[8, j] = "_";
            }

            for (int i = 2; i < 9; i++)  // dessin de la barre verticale de la potence
            {
                pendu[i, 4] = "|";
            }
            for (int j = 5; j < 16; j++)  // dessin du reste de la potence (barre horizontale + corde + poutre de soutien)
            {
                pendu[2, j] = "-";
            }
            pendu[2, 13] = "|";
            pendu[2, 6] = "/";
            pendu[3, 5] = "/";

        }




        public static void Tete(string[,] pendu)
        {
            pendu[3, 13] = "O";
        }



        public static void Corps(string[,] pendu)
        {
            pendu[4, 13] = "|";
            pendu[5, 13] = "|";
        }



        public static void Bras_Gauche(string[,] pendu)
        {
            pendu[4, 12] = "/";
        }



        public static void Bras_Droit(string[,] pendu)
        {
            pendu[4, 14] = "/";
        }



        public static void Jambe_Gauche(string[,] pendu)
        {
            pendu[6, 12] = "/";
        }



        public static void Jambe_Droite(string[,] pendu)
        {
            pendu[6, 14] = "/";
        }



        public static void Initialisation_Partie(string[,] pendu)
        {
            Console.WriteLine("********************");
            Console.WriteLine("*** JEU DU PENDU ***");
            Console.WriteLine("********************");
            Console.WriteLine();

            Console.WriteLine("Nom du Joueur 1 ?");
            string Joueur1 = Console.ReadLine();
            Console.WriteLine("Nom du Joueur 2 ?");
            string Joueur2 = Console.ReadLine();
            Console.WriteLine();

            int test1 = 1;
            string role1 = " ";
            string role2 = " ";
            while (test1 != 0)  // on s'assure avec cette boucle que le joueur choisisse bien une des reponses proposées (1 ou 2)
            {
                Console.WriteLine("Quel rôle souhaites-tu jouer {0} ? Tapes 1 pour 'faire deviner le mot' ou 2 pour 'chercher le mot' ", Joueur1);
                int reponse = int.Parse(Console.ReadLine());
                if (reponse == 1)
                {
                    role1 = "Choisisseur_Du_Mot";
                    role2 = "Chercheur_Du_Mot";
                    test1 = 0;
                }
                else if (reponse == 2)
                {
                    role1 = "Chercheur_Du_Mot";
                    role2 = "Choisisseur_Du_Mot";
                    test1 = 0;
                }
            }
            Console.WriteLine();

            int test_difficulte = 1;
            string mode_de_jeu = " ";
            while (test_difficulte!=0)
            {
                Console.WriteLine("CHOIX DE LA DIFFCIULTE ? Entrez 'facile'(le mot fera moins de 10 lettres) ou 'difficile' (le mot fera 10 lettres ou plus)");
                string reponse =Console.ReadLine();
                if (reponse == "facile")
                {
                    mode_de_jeu = "facile";
                    test_difficulte = 0;
                }
                else if (reponse == "difficile")
                {
                    mode_de_jeu = "difficile";
                    test_difficulte = 0;
                }
            }
            Console.WriteLine("La Partie va commencer ! {0} a le rôle du {1} , {2} a le rôle du {3}.", Joueur1, role1, Joueur2, role2);

            bool Recommencer = true;            
            while (Recommencer==true)
            {
                int test2 = 1;
                Game(Joueur1, Joueur2, role1, role2, pendu,mode_de_jeu);
                while(test2!=0)
                {
                    Console.WriteLine("Voulez-vous recommencer la Partie ? Tapes 1 pour 'oui' ou 2 pour 'non' ");
                    int reponse = int.Parse(Console.ReadLine());

                    if (reponse == 1)
                    {
                        test2 = 0;
                        int test3 = 1;
                        Initialiser_Pendu(pendu);
                        while (test3!=0)
                        {
                            Console.WriteLine("Souhaitez-vous échanger les rôles ? Tapes 1 pour 'oui' ou 2 pour 'non'");
                            int reponse2 = int.Parse(Console.ReadLine());
                            if (reponse2 == 1)
                            {
                                string copie_role1 = role1;
                                role1 = role2;
                                role2 = copie_role1;
                                test3 = 0;
                            }
                            else if (reponse2 == 2)
                            {
                                test3 = 0;
                            }
                        }
                    }
                    else if (reponse == 2)
                    {
                        test2 = 0;
                        Recommencer = false;
                    }
                }
                
            }


        }




        public static void Game(string Joueur1,string Joueur2,string role1, string role2, string[,] pendu,string mode_de_jeu) // fonction qui s'occuppe de l'interaction du jeu et du déroulement de la partie
        {

            if (role1== "Choisisseur_Du_Mot")
            {
                Console.WriteLine("{0} doit choisir un mot à faire deviner", Joueur1);
            }
            else
            {
                Console.WriteLine("{0} doit choisir un mot à faire deviner", Joueur2);
            }
            
            string motDevine = "";
            bool motValide = false;
            bool present_dico = false;
            while (!motValide) // Vérifie que le mot saisie est bien un mot existant
            {
                present_dico = false;
                motDevine = Console.ReadLine();
                foreach (string mots in InitialiserTabMots("dico_fr.txt"))
                {
                    string motMinuscule = mots.ToLower();
                    if (motDevine == motMinuscule)
                    {
                        present_dico = true;
                        if (mode_de_jeu=="facile")
                        {
                            if (motDevine.Length<10)
                            {
                                Console.WriteLine("le mot est valide");
                                motValide = true;
                            }
                        }
                        else
                        {
                            if (motDevine.Length>=10)
                            {
                                Console.WriteLine("le mot est valide");
                                motValide = true;
                            }
                        }

                    }
                }
                if (!motValide)
                {
                    if (present_dico==true & mode_de_jeu=="facile")
                    {
                        Console.WriteLine("Ce mot est trop long , recommencez !");
                    }
                    else if(present_dico == true & mode_de_jeu == "difficile")
                    {
                        Console.WriteLine("Ce mot est trop court , recommencez !");
                    }
                    else
                    {
                        Console.WriteLine("Ce mot n'est pas valide, veuillez recommencer!");
                    }
                }
            }
            Console.Clear();

            if (role1 == "Chercheur_Du_Mot")
            {
                Console.WriteLine("{0} doit trouver une lettre ou donner le mot directement", Joueur1);
            }
            else
            {
                Console.WriteLine("{0} doit trouver une lettre ou donner le mot directement", Joueur2);
            }
            
            AfficheMot(motDevine, pendu);

        }


        public static void AfficheMot(string motDevine, string[,] pendu)
        {

            char[] motCherche = new char[motDevine.Length];
            int nombreErreur = 0;
            bool partieGagne = false;
            bool partiePerdue = false;
            string motTrouve = "";


            for (int i = 0; i < motCherche.Length; i++)// initialisation du tableau de lettres déjà trouvées du mot à deviner
            {
                motCherche[i] = '_';
            }
            while (!partiePerdue && !partieGagne)
            {
                bool trouve = false;
                char lettreDevine = char.Parse(Console.ReadLine());
                for (int i = 0; i < motDevine.Length; i++)
                {
                    if (lettreDevine == motDevine[i])
                    {
                        motCherche[i] = lettreDevine;
                        trouve = true;
                    }
                }
                if (trouve==false)
                {
                    nombreErreur++;
                }
                foreach (char caractere in motCherche)
                {

                    Console.Write(caractere + " ");
                }
                Console.WriteLine();
                Console.WriteLine();
                Affiche_Pendu(pendu, nombreErreur);


                for (int i = 0; i < motDevine.Length; i++)
                {
                    motTrouve += motCherche[i];
                }
                if (motTrouve == motDevine && nombreErreur < 7)
                {

                    partieGagne = true;
                    Console.WriteLine("FELICITATION VOUS AVEZ TROUVE LE MOT");
                }

                if (nombreErreur >= 7)
                {
                    partiePerdue = true;
                    Console.WriteLine("DOMMAGE LE CHERCHEUR DE MOT A PERDU");
                }

            }   
        }



        public static void Affiche_Pendu(string[,] pendu, int Nb_Erreur)
        {
            switch (Nb_Erreur)  // A chaque nouvelle erreur, une partie du pendu devient visible
            {                
                case 1:
                    Potence(pendu);
                    break;
                case 2:
                    Potence(pendu);
                    Tete(pendu);
                    break;
                case 3:
                    Potence(pendu);
                    Tete(pendu);
                    Corps(pendu);
                    break;
                case 4:
                    Potence(pendu);
                    Tete(pendu);
                    Corps(pendu);
                    Bras_Gauche(pendu);
                    break;
                case 5:
                    Potence(pendu);
                    Tete(pendu);
                    Corps(pendu);
                    Bras_Gauche(pendu);
                    Bras_Droit(pendu);
                    break;
                case 6:
                    Potence(pendu);
                    Tete(pendu);
                    Corps(pendu);
                    Bras_Gauche(pendu);
                    Bras_Droit(pendu);
                    Jambe_Gauche(pendu);
                    break;
                case 7:
                    Potence(pendu);
                    Tete(pendu);
                    Corps(pendu);
                    Bras_Gauche(pendu);
                    Bras_Droit(pendu);
                    Jambe_Gauche(pendu);
                    Jambe_Droite(pendu);
                    break;
            }

            for (int i = 0; i < pendu.GetLength(0); i++)    // affichage du pendu
            {
                for (int j = 0; j < pendu.GetLength(1); j++)
                {
                    Console.Write(pendu[i, j]);
                }
                Console.WriteLine();
            }

        }
    }
}

// DESSIN DU PENDU :
/* +------------------+
   |                  |
   |   |-/------|--   |
   |   |/       0     | 
   |   |       /|/    |
   |   |        |     |
   |   |       / /    |
   |   |              |
   |  _|__________    |
   |                  |
   +------------------+ */
