﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Essai_Maîwen
{
    class Program
    {

        public static void Main()
        {
            int dessin = DessinPendu(10, new char[20]);
        }



        public static int DessinPendu(int NombreErreurs, char[] TableauMot)
        {

            char[,] Dessin = new char[10, 21];
            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 21; j++)
                {
                    Dessin[0, j] = '*';
                    Dessin[9, j] = '*';
                    Dessin[i, 0] = '*';
                    Dessin[i, 20] = '*';
                }
            }

            if (NombreErreurs >= 1)
            {
                for (int l = 5; l < 15; l++) // barre horizontale en bas de la potence
                {
                    Dessin[8, l] = '_';
                }

                if (NombreErreurs >= 2)
                {
                    for (int h = 3; h < 9; h++)// hauteur de la potence
                    {
                        Dessin[h, 7] = '|';
                    }

                    if (NombreErreurs >= 3) // barre horizontale en haut de la potence
                    {
                        for (int b = 7; b < 14; b++)
                        {
                            Dessin[2, b] = '_';
                        }

                        

                            if (NombreErreurs >= 4)
                            {
                                Dessin[3, 8] = '/'; // support de la potence

                                if (NombreErreurs >= 5)
                                {
                                    Dessin[3, 12] = '|';

                                    if (NombreErreurs >= 6)
                                    {
                                        Dessin[4, 12] = 'O'; // tete du pendu

                                        if (NombreErreurs >= 7)
                                        {
                                            for (int c = 5; c < 7; c++)// corps du pendu
                                            {
                                                Dessin[c, 12] = '|';
                                            }
                                            if (NombreErreurs >= 8)
                                            {
                                                Dessin[5, 11] = '/';

                                                if (NombreErreurs >= 9)
                                                {
                                                    Dessin[5, 13] = '\\';

                                                    if (NombreErreurs >= 10)
                                                    {
                                                        Dessin[7, 11] = '/';

                                                        if (NombreErreurs >= 11)
                                                        {
                                                            Dessin[7, 13] = '\\';
                                                            Console.WriteLine("Dommage, vous avez perdu. Le mot était : ");
                                                            AfficherTableauChar(TableauMot);
                                                            MenuPrincipal();
                                                        }

                                                    }
                                                }
                                            }

                                        }
                                    
                                }
                            }

                        }
                    }
                }
            }
            AfficherDessin(Dessin);
            return NombreErreurs;


        }

        public static char[,] AfficherDessin(char[,] Dessin)
        {
            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 21; j++)
                {
                    Console.Write(Dessin[i, j]);
                }
                Console.Write("\n");
            }

            return Dessin;
        }
    }
}
